# PyDesktopClock #

>This is a pip package for a windows widget that display a clock.
