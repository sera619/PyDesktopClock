# PyDesktopClock #

>This is a pip package for a windows widget that display a clock.

## Usage ##

> To use this clock just install it with.
>
> ```CMD
>   pip install -i https://test.pypi.org/simple/ PyDesktopClock==0.0.1
>```
>
> or
>
> ```CMD
>   pip3 install -i https://test.pypi.org/simple/ PyDesktopClock==0.0.1
>```
>
> After u finished intalling you can import the clock in a python file
>
>```py
>from PyDesktopClock import DesktopClock
>
>DesktopClock.run()
>```
>
> Run the script and a Clock should apper on your display
